# docker_wordpress_as_a_services
User can access the wordpress using mobile web_browser and can also launch the docker-compose file to launch new os using JUICE_SSH application in android mobile.
